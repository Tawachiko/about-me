import sqlite3
from flask import Flask , jsonify
import json

app = Flask(__name__)
DATABASE = 'kenall.db'

@app.route("/GetJpYubin/<id>")
def get_jpyubin(id):
    # SQLite データベースに接続
    conn = sqlite3.connect(DATABASE)
    cur = conn.cursor()
    # データの取り出し（SELECT）
    cur.execute(f'SELECT field3 , field7 , field8 , field9 , field4 , field5 , field6 FROM utf_ken_all WHERE field3 = {id};')
    results = cur.fetchall()
    # 取り出したデータを辞書型で整形
    data_list = [{'yubin': r[0], 'pref': r[1], 'city': r[2]} for r in results]
    # JSON データを UTF-8 のまま作成
    json_data = json.dumps(data_list, ensure_ascii=False)
    # DBから切断
    conn.close()
    # レスポンス
    return json_data

